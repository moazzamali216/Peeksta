

// Dark Theme
if(document.getElementById('theme-toggle')){

    window.addEventListener('load',function () {
        if(localStorage.getItem('color-theme') == 'dark') {
            document.documentElement.classList.add('dark');
            localStorage.setItem('color-theme', 'dark');
            themeToggleLightIcon.classList.remove('hidden');

        }else {
            document.documentElement.classList.remove('dark');
            localStorage.setItem('color-theme', 'light');
            themeToggleDarkIcon.classList.remove('hidden');
        }
    })

    var themeToggleDarkIcon = document.getElementById('theme-toggle-dark-icon');
    var themeToggleLightIcon = document.getElementById('theme-toggle-light-icon');

    // Change the icons inside the button based on previous settings
    if (localStorage.getItem('color-theme') === 'dark' || (!('color-theme' in localStorage) && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
        themeToggleLightIcon.classList.remove('hidden');
    } else {
        themeToggleDarkIcon.classList.remove('hidden');
    }

    var themeToggleBtn = document.getElementById('theme-toggle');

    themeToggleBtn.addEventListener('click', function() {
        console.log('working')

        // toggle icons inside button
        themeToggleDarkIcon.classList.toggle('hidden');
        themeToggleLightIcon.classList.toggle('hidden');

        // if set via local storage previously
        if (localStorage.getItem('color-theme')) {
            if (localStorage.getItem('color-theme') === 'light') {
                document.documentElement.classList.add('dark');
                localStorage.setItem('color-theme', 'dark');
            } else {
                document.documentElement.classList.remove('dark');
                localStorage.setItem('color-theme', 'light');
            }

        // if NOT set via local storage previously
        } else {
            if (document.documentElement.classList.contains('dark')) {
                document.documentElement.classList.remove('dark');
                localStorage.setItem('color-theme', 'light');
            } else {
                document.documentElement.classList.add('dark');
                localStorage.setItem('color-theme', 'dark');
            }
        }
        
    });
}


// work with sidebar
var btn     = document.getElementById('sliderBtn'),
sideBar = document.getElementById('sideBar'),
sideBarHideBtn = document.getElementById('sideBarHideBtn');

// show sidebar 
// btn.addEventListener('click' , function(){    
//     if (sideBar.classList.contains('-ml-72')) {
//         sideBar.classList.replace('-ml-72' , 'ml-0');
        
//     };
// });

// hide sideBar    
if(document.querySelector(".sideBarHideBtn")){
    sideBarHideBtn.addEventListener('click' , function(){            
        if (sideBar.classList.contains('ml-0' , 'slideInLeft')) {      
            var _class = function(){
                sideBar.classList.remove('slideInLeft');
                sideBar.classList.add('slideOutLeft');
        
                console.log('hide');              
            };
            var animate = async function(){
                await _class();
    
                setTimeout(function(){
                    sideBar.classList.replace('ml-0' , '-ml-72');
                    console.log('animated');
                } , 300);                                                
                
            };            
                    
            _class(); 
            animate();
        };
    });
}
// end with sidebar

// $( document ).ready(function() {
//     if ($(window).width() > 1024) {
//         $("#sideBar").removeClass('hide-sidebar')
//     }
// });
// $( document ).ready(function() {
//     if ($(window).width() < 1024) {
//         $("#sideBar").removeClass('animate__bounceInLeft');
//     }
// });
// hideSide bar on desktop
$(function() {
    $(".x-close").on('click', function(){
        // sideBar.classList.replace('lg:ml-0' , '-ml-72');
        $("#sideBar").addClass('hide-sidebar')
        $(".content-class").removeClass('content-swipe');
        $("#sideBar").removeClass('animate__bounceInLeft');

    })
    $(".x-open").on('click', function(){
        $("#sideBar").removeClass('hide-sidebar')
        $(".content-class").addClass('content-swipe')
        $("#sideBar").addClass('animate__bounceInLeft');
    })
});


if(document.querySelector(".range-input input")){
  // Range Slider Js - 1
    const rangeInput = document.querySelectorAll(".range-input input"),
    priceInput = document.querySelectorAll(".price-input input"),
    range = document.querySelector(".slider .progress");
    let priceGap = 1000;

    priceInput.forEach(input =>{
        input.addEventListener("input", e =>{
            let minPrice = parseInt(priceInput[0].value),
            maxPrice = parseInt(priceInput[1].value);
            
            if((maxPrice - minPrice >= priceGap) && maxPrice <= rangeInput[1].max){
                if(e.target.className === "input-min"){
                    rangeInput[0].value = minPrice;
                    range.style.left = ((minPrice / rangeInput[0].max) * 100) + "%";
                }else{
                    rangeInput[1].value = maxPrice;
                    range.style.right = 100 - (maxPrice / rangeInput[1].max) * 100 + "%";
                }
            }
        });
    });

    rangeInput.forEach(input =>{
        input.addEventListener("input", e =>{
            let minVal = parseInt(rangeInput[0].value),
            maxVal = parseInt(rangeInput[1].value);

            if((maxVal - minVal) < priceGap){
                if(e.target.className === "range-min"){
                    rangeInput[0].value = maxVal - priceGap
                }else{
                    rangeInput[1].value = minVal + priceGap;
                }
            }else{
                priceInput[0].value = minVal;
                priceInput[1].value = maxVal;
                range.style.left = ((minVal / rangeInput[0].max) * 100) + "%";
                range.style.right = 100 - (maxVal / rangeInput[1].max) * 100 + "%";
            }
        });
    });

    // Range Slider Js - 2

    const rangeInput2 = document.querySelectorAll(".range-2 input"),
    priceInput2 = document.querySelectorAll(".price-2 input"),
    range2 = document.querySelector(".slide-2 .progress-2");
    let priceGap2 = 1000;

    priceInput2.forEach(input =>{
        input.addEventListener("input", e =>{
            let minPrice = parseInt(priceInput2[0].value),
            maxPrice = parseInt(priceInput2[1].value);
            
            if((maxPrice - minPrice >= priceGap) && maxPrice <= rangeInput2[1].max){
                if(e.target.className === "input-min"){
                    rangeInput2[0].value = minPrice;
                    range2.style.left = ((minPrice / rangeInput2[0].max) * 100) + "%";
                }else{
                    rangeInput2[1].value = maxPrice;
                    range2.style.right = 100 - (maxPrice / rangeInput2[1].max) * 100 + "%";
                }
            }
        });
    });

    rangeInput2.forEach(input =>{
        input.addEventListener("input", e =>{
            let minVal = parseInt(rangeInput2[0].value),
            maxVal = parseInt(rangeInput2[1].value);

            if((maxVal - minVal) < priceGap){
                if(e.target.className === "range-min"){
                    rangeInput2[0].value = maxVal - priceGap
                }else{
                    rangeInput2[1].value = minVal + priceGap;
                }
            }else{
                priceInput2[0].value = minVal;
                priceInput2[1].value = maxVal;
                range2.style.left = ((minVal / rangeInput2[0].max) * 100) + "%";
                range2.style.right = 100 - (maxVal / rangeInput2[1].max) * 100 + "%";
            }
        });
    });
}



if(document.querySelector("#profile-tab-example")){
    // create an array of objects with the id, trigger element (eg. button), and the content element
    const tabElements = [
        {
            id: 'profile',
            triggerEl: document.querySelector('#profile-tab-example'),
            targetEl: document.querySelector('#profile-example')
        },
        {
            id: 'dashboard',
            triggerEl: document.querySelector('#dashboard-tab-example'),
            targetEl: document.querySelector('#dashboard-example')
        },
        {
            id: 'settings',
            triggerEl: document.querySelector('#settings-tab-example'),
            targetEl: document.querySelector('#settings-example')
        }
        ];

        // options with default values
        const options = {
            defaultTabId: 'settings',
            activeClasses: 'text-[#7166F9] hover:text-blue-600 dark:text-blue-500 dark:hover:text-blue-400 border-[#7166F9] dark:border-blue-500',
            inactiveClasses: 'text-gray-500 hover:text-gray-600 dark:text-gray-400 border-gray-100 hover:border-gray-300 dark:border-gray-700 dark:hover:text-gray-300',
            onShow: () => {
                console.log('tab is shown');
            }
        };
    const tabs = new Tabs(tabElements, options);
}

// filter Services
if(document.querySelector(".gallery-filter")){
    const filterContainer = document.querySelector(".gallery-filter"),
    galleryItems = document.querySelectorAll(".gallery-item");

    filterContainer.addEventListener("click", (event) =>{
    if(event.target.classList.contains("filter-item")){
        // deactivate existing active 'filter-item'
        filterContainer.querySelector(".active").classList.remove("active");
        // activate new 'filter-item'
        event.target.classList.add("active");
        const filterValue = event.target.getAttribute("data-filter");
        galleryItems.forEach((item) =>{
        if(item.classList.contains(filterValue) || filterValue === 'all'){
            item.classList.remove("hide");
            item.classList.add("show");
        }else{
            item.classList.remove("show");
            item.classList.add("hide");
        }
        });
    }
    });
}

if(document.querySelector(".accordion-header")){
    const accordionHeader = document.querySelectorAll(".accordion-header");
    accordionHeader.forEach((header) => {
        header.addEventListener("click", function () {
            const accordionContent = header.parentElement.querySelector(".accordion-content");
            let accordionMaxHeight = accordionContent.style.maxHeight;

            // Condition handling
            if (accordionMaxHeight == "0px" || accordionMaxHeight.length == 0) {
            accordionContent.style.maxHeight = `${accordionContent.scrollHeight + 32}px`;
            header.querySelector(".fa-caret-right").classList.remove("-rotate-90");
            } else {
            accordionContent.style.maxHeight = `0px`;
            header.querySelector(".fa-caret-right").classList.add("-rotate-90");
            }
        });
    });
}


if($('.Mimmpeach')){
    $(document).ready(function(){
      $('.Mimmpeach').slick({
          infinite: true,
          slidesToShow: 6,
          slidesToScroll: 1,
          dots: false,
          autoplay: false,
          autoplaySpeed: 2000,
          prevArrow: $('.pp-prev-1'),
          nextArrow: $('.pp-next-1'),
          responsive: [
              {
                breakpoint: 1536,
                settings: {
                  slidesToShow: 5
                }
              },
              {
                breakpoint: 1280,
                settings: {
                  slidesToShow: 4
                }
              },
              {
                breakpoint: 768,
                settings: {
                  slidesToShow: 3
                }
              },
              {
                breakpoint: 550,
                settings: {
                  slidesToShow: 2
                }
              },
              {
                breakpoint: 400,
                settings: {
                  slidesToShow: 1
                }
              }
            ]
      });
  });
}


if($('#picker')){
  $(document).ready(function(){
    $("#picker,#picker-2").spectrum({
        showInput: true,
        showAlpha: true,
        color: "#7166F9",
    })
});
}
