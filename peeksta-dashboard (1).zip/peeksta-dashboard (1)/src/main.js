

$(function() {
    $(window).on("scroll", function() {
        if($(window).scrollTop() > 100) {
            $(".header__top").addClass("nav__active");
            $(".change-clr").addClass('btn-black');
            $(".change-clr").removeClass('btn-white');

        } else {
           $(".header__top").removeClass("nav__active");
           $(".change-clr").removeClass('btn-black');
           $(".change-clr").addClass('btn-white');

        }
    });
});

$('.slider-for').slick({
    slidesToShow: 1,
    slidesToScroll: 1,
    arrows: false,
    fade: true,
    asNavFor: '.slider-nav'
  });
  $('.slider-nav').slick({
    slidesToShow: 1,
    slidesToScroll: 1,
    asNavFor: '.slider-for',
    dots: false,
    focusOnSelect: true,
    arrows: false,
    autoplay: true,
  });


const accordionItems = [
    {
        id: 'accordion-example-heading-1',
        triggerEl: document.querySelector('#accordion-example-heading-1'),
        targetEl: document.querySelector('#accordion-example-body-1'),
        active: true
    },
    {
        id: 'accordion-example-heading-2',
        triggerEl: document.querySelector('#accordion-example-heading-2'),
        targetEl: document.querySelector('#accordion-example-body-2'),
        active: false
    },
    {
        id: 'accordion-example-heading-3',
        triggerEl: document.querySelector('#accordion-example-heading-3'),
        targetEl: document.querySelector('#accordion-example-body-3'),
        active: false
    },
    {
        id: 'accordion-example-heading-4',
        triggerEl: document.querySelector('#accordion-example-heading-4'),
        targetEl: document.querySelector('#accordion-example-body-4'),
        active: false
    },
    {
        id: 'accordion-example-heading-5',
        triggerEl: document.querySelector('#accordion-example-heading-5'),
        targetEl: document.querySelector('#accordion-example-body-5'),
        active: false
    },
    {
        id: 'accordion-example-heading-6',
        triggerEl: document.querySelector('#accordion-example-heading-6'),
        targetEl: document.querySelector('#accordion-example-body-6'),
        active: false
    }
];

// options with default values
const options = {
    alwaysOpen: true,
    activeClasses: 'bg-[#44b98027] text-[#44B980]',
    inactiveClasses: 'text-black bg-white dark:text-gray-400',
};

const accordion = new Accordion(accordionItems, options);

